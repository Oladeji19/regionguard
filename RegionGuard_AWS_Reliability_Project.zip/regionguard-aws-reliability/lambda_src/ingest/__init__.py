"""Health-event ingestion Lambda."""

